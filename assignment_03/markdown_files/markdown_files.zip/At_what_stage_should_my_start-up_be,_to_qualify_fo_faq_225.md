At_what_stage_should_my_start-up_be,_to_qualify_fo



At what stage should my start-up be, to qualify for this investment?
====================================================================

We invest in start-ups from the pre-seed stage all the way to Series rounds. If your startup is at a stage that is ready to scale beyond proof of concept and requires external funding to do so, do come and talk to us at entrepreneurship@sutd.edu.sg.

[VIE](https://www.sutd.edu.sg/tag/vie/) [VIE Funding](https://www.sutd.edu.sg/tag/vie-funding/)

---

