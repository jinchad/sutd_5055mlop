Can_males_serving_Singapore_national_service_apply



Can males serving Singapore national service apply? Will places be reserved for NSF for post-NS admission?
==========================================================================================================

Yes. NSF can apply and places will be reserved for successful applicants who have accepted the offer.

[SUTD-Duke-NUS](https://www.sutd.edu.sg/tag/sutd-duke-nus/)

---

