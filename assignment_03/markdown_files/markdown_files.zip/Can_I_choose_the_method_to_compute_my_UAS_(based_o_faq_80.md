Can_I_choose_the_method_to_compute_my_UAS_(based_o



Can I choose the method to compute my UAS (based on current or revised A-Level curriculum)?
===========================================================================================

The method to compute UAS will depend on the year the applicant sat for the GCE A-Level examinations and the year of application. Applicants will not be able to select the UAS computation method.

[Admissions](https://www.sutd.edu.sg/tag/admissions/)

---

