Am_I_entitled_to_leave__medical_benefits_during_th



Am I entitled to leave/ medical benefits during the internship?
===============================================================

No, it is not mandated that the company provides you with leave or any other employee benefit during the internship. If a company chooses to do so, it will be according to the company’s HR policy. In the event that you require a leave of absence, please inform your supervisor and let us know via e-mail at careers@sutd.edu.sg and studentadmin@sutd.edu.sg once you have obtained their approval. If the leave taken is on medical grounds, please have your medical certificate/appointment card endorsed by your supervisor (via certified photocopy if necessary), and send a scanned copy of the endorsed document to us.

[Career development](https://www.sutd.edu.sg/tag/career-development/)

---

