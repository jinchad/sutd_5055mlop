Can_I_get_SUTD_talents_to_join_my_start-up__-_Sing



Can I get SUTD talents to join my start-up?
===========================================

At SUTD, students are encouraged to participate in a myriad of activities to broaden their horizons and experiences. If there is a need, we can help you publicise employment opportunities through our channels and network. Through participating in our programmes, you will also have the opportunity to meet with SUTD students and alumni.

[VIE](https://www.sutd.edu.sg/tag/vie/)

---

