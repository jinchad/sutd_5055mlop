Are_there_modules_relating_to_fields_of_studies_li



Are there modules relating to fields of studies like Material Science and Nanotechnology?
=========================================================================================

Although we do not have a material science and nanotechnology track, it is possible to take classes that focus on these areas via the [self-directed track](/epd/education/undergraduate/specialisation-tracks/self-directed-programme/). Currently, there are several related subjects that are currently offered in EPD for every pillar term. We would encourage students to consult and speak with the faculty mentors or pillar administrators on the classes one should take to pursue their interest in a given area.

[EPD](https://www.sutd.edu.sg/epd/tag/epd/)

---

