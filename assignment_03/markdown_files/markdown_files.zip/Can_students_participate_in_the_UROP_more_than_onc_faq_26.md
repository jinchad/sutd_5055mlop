Can_students_participate_in_the_UROP_more_than_onc



Can students participate in the UROP more than once?
====================================================

Yes you can. However, priority will be given to first-time UROPers.

[UROP](https://www.sutd.edu.sg/tag/urop/)

---

