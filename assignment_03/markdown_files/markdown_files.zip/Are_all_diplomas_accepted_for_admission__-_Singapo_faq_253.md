Are_all_diplomas_accepted_for_admission__-_Singapo



Are all diplomas accepted for admission?
========================================

Generally, diplomas from the School of Engineering, Information Technology, Architecture or Sciences are considered more relevant to SUTD’s courses and hence will be assessed more favourably for admission. However, other diplomas may still be considered on a case-by-case basis.

[Admissions](https://www.sutd.edu.sg/tag/admissions/)

---

