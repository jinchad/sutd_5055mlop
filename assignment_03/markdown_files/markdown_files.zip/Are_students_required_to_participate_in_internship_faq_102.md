Are_students_required_to_participate_in_internship



Are students required to participate in internships while studying at SUTD?
===========================================================================

All SUTD undergraduates are required to complete a 16-week internship. More information on [SUTD’s career services can be found here](/campus-life/career-development/).

[Admissions](https://www.sutd.edu.sg/tag/admissions/)

---

