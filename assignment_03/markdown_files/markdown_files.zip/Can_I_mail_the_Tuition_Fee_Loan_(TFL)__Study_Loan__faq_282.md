Can_I_mail_the_Tuition_Fee_Loan_(TFL)__Study_Loan_



Can I mail the Tuition Fee Loan (TFL)/ Study Loan (SL) application documents to DBS Singapore?
==============================================================================================

No. International students with guarantor who is not residing or working in Singapore will have to submit the application documents in person to **DBS Singapore Raffles Place Branch** to process the loan agreement.




Digital TFL Application is only applicable to applications with Guarantors who are Singapore Citizens/Permanent Residents and Foreigners who are pass-holders (residing or working in Singapore).

[Admissions](https://www.sutd.edu.sg/tag/admissions/)

---

