Are_all_students_allowed_to_take_a_minor_in_SUTD_a



Are all students allowed to take a minor in SUTD and what are the requirements?
===============================================================================

Currently, students taking up either CSD (formerly ISTD), DAI, EPD or ESD will be able to pursue a minor on top of their major, potentially without having to overload on the number of modules (this depends on the specialisation chosen, if any). You will get to indicate your preferred minor after you have made your choice of major at the end of Term 3. Both the major and minor requirements must be completed within the normal candidature of the undergraduate programme, i.e. 8 terms.




More information on [minors can be found here](/education/undergraduate/minors/).

[Admissions](https://www.sutd.edu.sg/tag/admissions/)

---

