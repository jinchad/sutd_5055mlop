Can_you_share_some_projects_that_are_created_by_EP



Can you share some projects that are created by EPD students?
=============================================================

Check out the following video links where some examples of the EPD projects are showcased:



* <https://youtu.be/texOV407GUM>
* <https://youtu.be/t5qntiav1OA>
* <https://youtu.be/eR3a9cvsIzI>

[EPD](https://www.sutd.edu.sg/epd/tag/epd/)

---

