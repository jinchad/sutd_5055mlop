Anthonia___Leonardo_–_SUTD_Bursary_-_Singapore_Uni



…

 [Study / Bursary Awards](/admissions/undergraduate/financing-options-and-aid/financial-aid/study-bursary-awards) 

Anthonia & Leonardo – SUTD Bursary

[Study / Bursary Awards](https://www.sutd.edu.sg/admissions/undergraduate/financing-options-and-aid/financial-aid/study-bursary-awards)

Financial options and aid
=========================

[Char Yong (Dabu) Association – SUTD Bursary Award](/admissions/undergraduate/financing-options-and-aid/financial-aid/study-bursary-awards/char-yong-dabu-association-sutd-bursary-award/#tabs)

[SUTD Study Award](/admissions/undergraduate/financing-options-and-aid/financial-aid/study-bursary-awards/sutd-study-award/#tabs)

[TAK Bursary Award](/admissions/undergraduate/financing-options-and-aid/financial-aid/study-bursary-awards/tak-bursary-award/#tabs)

[Tan Kong Piat – SUTD Bursary](/admissions/undergraduate/financing-options-and-aid/financial-aid/study-bursary-awards/tan-kong-piat-sutd-bursary/#tabs)

[Tan Wu Hao – SUTD Bursary Award](/admissions/undergraduate/financing-options-and-aid/financial-aid/study-bursary-awards/tan-wu-hao-sutd-bursary-award/#tabs)

[The MCF – L Solomon Lodge Wandailan Hardship Grant](/admissions/undergraduate/financing-options-and-aid/financial-aid/study-bursary-awards/the-mcf-l-solomon-lodge-wandailan-hardship-grant/#tabs)

[The Silent Minority Bursary](/admissions/undergraduate/financing-options-and-aid/financial-aid/study-bursary-awards/the-silent-minority-bursary/#tabs)

[Tian Kong & Kancanarama Buddhist Temple – SUTD Bursary Award](/admissions/undergraduate/financing-options-and-aid/financial-aid/study-bursary-awards/tian-kong-kancanarama-buddhist-temple-sutd-bursary-award/#tabs)

[Tony Lui Wing Kwong – SUTD Bursary](/admissions/undergraduate/financing-options-and-aid/financial-aid/study-bursary-awards/tony-lui-wing-kwong-sutd-bursary/#tabs)

[Von Lee Yong Miang – SUTD Bursary Award](/admissions/undergraduate/financing-options-and-aid/financial-aid/study-bursary-awards/von-lee-yong-miang-sutd-bursary-award/#tabs)

[Yangzheng Foundation Study Award](/admissions/undergraduate/financing-options-and-aid/financial-aid/study-bursary-awards/yangzheng-foundation-study-award/#tabs)

[Chuan Hup – SUTD Bursary Award](/admissions/undergraduate/financing-options-and-aid/financial-aid/study-bursary-awards/chuan-hup-sutd-bursary-award/#tabs)

[Chong Yee Temple – SUTD Bursary Award](/admissions/undergraduate/financing-options-and-aid/financial-aid/study-bursary-awards/chong-yee-temple-sutd-bursary-award/#tabs)

[Cheng Hong Siang Tng – SUTD Bursary Award](/admissions/undergraduate/financing-options-and-aid/financial-aid/study-bursary-awards/cheng-hong-siang-tng-sutd-bursary-award/#tabs)

[Thekchen Choling Singapore – SUTD Bursary](/admissions/undergraduate/financing-options-and-aid/financial-aid/study-bursary-awards/thekchen-choling-singapore-sutd-bursary/#tabs)

[Applied Materials – SUTD Study Grant](/admissions/undergraduate/financing-options-and-aid/financial-aid/study-bursary-awards/applied-materials-sutd-study-grant/#tabs)

[Anthonia & Leonardo – SUTD Bursary](/admissions/undergraduate/financing-options-and-aid/financial-aid/study-bursary-awards/anthonia-leonardo-sutd-bursary/#tabs)

[Agus – SUTD Bursary](/admissions/undergraduate/financing-options-and-aid/financial-aid/study-bursary-awards/agus-sutd-bursary/#tabs)

[Loo Geok Eng Foundation – SUTD Bursary Award](/admissions/undergraduate/financing-options-and-aid/financial-aid/study-bursary-awards/financial-aid-loo-geok-eng-foundation-sutd-bursary-award/#tabs)

[AM Family Capital Foundation – SUTD Bursary](/admissions/undergraduate/financing-options-and-aid/financial-aid/study-bursary-awards/am-family-capital-foundation-sutd-bursary/#tabs)

[Soh-Bin-Seng-SUTD-Bursary](/admissions/undergraduate/financing-options-and-aid/financial-aid/study-bursary-awards/soh-bin-seng-sutd-bursary/#tabs)

[Worldwide Hotels – Choo Chong Ngen Bursary Award](/admissions/undergraduate/financing-options-and-aid/financial-aid/study-bursary-awards/worldwide-hotels-choo-chong-ngen-bursary-award/#tabs)

[Henry and Hailey Qian Bursary](/admissions/undergraduate/financing-options-and-aid/financial-aid/study-bursary-awards/henry-and-hailey-qian-bursary/#tabs)

[SM Jaleel Foundation – SUTD Bursary Award](/admissions/undergraduate/financing-options-and-aid/financial-aid/study-bursary-awards/sm-jaleel-foundation-sutd-bursary-award/#tabs)

[Bo Rui Foundation – SUTD Bursary Award](/admissions/undergraduate/financing-options-and-aid/financial-aid/study-bursary-awards/bo-rui-foundation-sutd-bursary-award/#tabs)

[SUTD – Malaysian Community Bursary](/admissions/undergraduate/financing-options-and-aid/financial-aid/study-bursary-awards/sutd-malaysian-community-bursary/#tabs)

[SUTD Bursary III](/admissions/undergraduate/financing-options-and-aid/financial-aid/study-bursary-awards/sutd-bursary-iii/#tabs)

[GEA – SUTD Bursary Award](/admissions/undergraduate/financing-options-and-aid/financial-aid/study-bursary-awards/gea-sutd-bursary-award/#tabs)

[Mapletree Bursary Award](/admissions/undergraduate/financing-options-and-aid/financial-aid/study-bursary-awards/mapletree-bursary-award/#tabs)

[CSE Global Engineering Bursary Award](/admissions/undergraduate/financing-options-and-aid/financial-aid/study-bursary-awards/cse-global-engineering-bursary-award/#tabs)

[Decision Science Agency – SUTD Study Award](/admissions/undergraduate/financing-options-and-aid/financial-aid/study-bursary-awards/decision-science-agency-sutd-study-award/#tabs)

[Deutsche Bank Study Award](/admissions/undergraduate/financing-options-and-aid/financial-aid/study-bursary-awards/deutsche-bank-study-award/#tabs)

[Goh Foundation Bursary Award](/admissions/undergraduate/financing-options-and-aid/financial-aid/study-bursary-awards/goh-foundation-bursary-award/#tabs)

[Irene Tan Liang Kheng Empowerment Award](/admissions/undergraduate/financing-options-and-aid/financial-aid/study-bursary-awards/irene-tan-liang-kheng-empowerment-award/#tabs)

[IWA Gyan Jyoti Study Award](/admissions/undergraduate/financing-options-and-aid/financial-aid/study-bursary-awards/iwa-gyan-jyoti-study-award/#tabs)

[Kathy Goh – SUTD Bursary](/admissions/undergraduate/financing-options-and-aid/financial-aid/study-bursary-awards/kathy-goh-sutd-bursary/#tabs)

[Keppel Bursary Award](/admissions/undergraduate/financing-options-and-aid/financial-aid/study-bursary-awards/keppel-bursary-award/#tabs)

[Legend Group – SUTD Bursary](/admissions/undergraduate/financing-options-and-aid/financial-aid/study-bursary-awards/legend-group-sutd-bursary/#tabs)

[Lim Pu Leh – SUTD Bursary Award](/admissions/undergraduate/financing-options-and-aid/financial-aid/study-bursary-awards/lim-pu-leh-sutd-bursary-award/#tabs)

[Linn In Hua Bursary Award](/admissions/undergraduate/financing-options-and-aid/financial-aid/study-bursary-awards/linn-in-hua-bursary-award/#tabs)

[Lions Community Service Foundation Bursary Award](/admissions/undergraduate/financing-options-and-aid/financial-aid/study-bursary-awards/lions-community-service-foundation-bursary-award/#tabs)

[Lockheed Martin – SUTD Study Grant](/admissions/undergraduate/financing-options-and-aid/financial-aid/study-bursary-awards/lockheed-martin-sutd-study-grant/#tabs)

[CK Than – SUTD Bursary](/admissions/undergraduate/financing-options-and-aid/financial-aid/study-bursary-awards/ck-than-sutd-bursary/#tabs)

[Mapletree – Paul Ma Kah Woh Bursary](/admissions/undergraduate/financing-options-and-aid/financial-aid/study-bursary-awards/mapletree-paul-ma-kah-woh-bursary/#tabs)

[Mapletree – Tsang Yam Pui Bursary](/admissions/undergraduate/financing-options-and-aid/financial-aid/study-bursary-awards/mapletree-tsang-yam-pui-bursary/#tabs)

[The Ngee Ann Kongsi Bursary Award](/admissions/undergraduate/financing-options-and-aid/financial-aid/study-bursary-awards/the-ngee-ann-kongsi-bursary-award/#tabs)

[Poh Say Lam Family (傅世南家族) – SUTD Bursary](/admissions/undergraduate/financing-options-and-aid/financial-aid/study-bursary-awards/poh-say-lam-family-%e5%82%85%e4%b8%96%e5%8d%97%e5%ae%b6%e6%97%8f-sutd-bursary/#tabs)

[Poh Tiong Choon Logistics Limited – SUTD Bursary](/admissions/undergraduate/financing-options-and-aid/financial-aid/study-bursary-awards/poh-tiong-choon-logistics-limited-sutd-bursary/#tabs)

[RQAM Study Grant](/admissions/undergraduate/financing-options-and-aid/financial-aid/study-bursary-awards/rqam-study-grant/#tabs)

[Samir Arora – SUTD Bursary](/admissions/undergraduate/financing-options-and-aid/financial-aid/study-bursary-awards/samir-arora-sutd-bursary/#tabs)

[Sing Lun – SUTD Bursary](/admissions/undergraduate/financing-options-and-aid/financial-aid/study-bursary-awards/sing-lun-sutd-bursary/#tabs)

[Singapore Leong Khay Huay Kuan Bursary](/admissions/undergraduate/financing-options-and-aid/financial-aid/study-bursary-awards/singapore-leong-khay-huay-kuan-bursary/#tabs)

[Singapore Pawnbrokers' Association – SUTD Bursary](/admissions/undergraduate/financing-options-and-aid/financial-aid/study-bursary-awards/singapore-pawnbrokers-association-sutd-bursary/#tabs)

[Sri Gnanananda Giri Peetam – SUTD Bursary Award](/admissions/undergraduate/financing-options-and-aid/financial-aid/study-bursary-awards/sri-gnanananda-giri-peetam-sutd-bursary-award/#tabs)

[SUTD Alumni Bursary](/admissions/undergraduate/financing-options-and-aid/financial-aid/study-bursary-awards/sutd-alumni-bursary/#tabs)

[SUTD Bursary Award](/admissions/undergraduate/financing-options-and-aid/financial-aid/study-bursary-awards/sutd-bursary-award/#tabs)

### **Anthonia & Leonardo – SUTD Bursary**




The Anthonia & Leonardo – SUTD Bursary is established to provide financial assistance to deserving students pursuing their studies at SUTD.






##### **Eligibility**




* Open to Singapore Citizens, Singapore Permanent Residents or International Students
* Full-time SUTD undergraduate students in any year of study and in any degree programme
* Good moral character and community spirit; and
* Demonstrated financial need with monthly household Per Capita Income of S$2,500 and below




##### **Tenure**




* Each Award is tenable for one year only




##### **Benefits of Award**




* S$7,500 per academic year
* Award is for tuition fees and study-related expenses.
* No bond attached




##### **Things to Note**




Recipients must take up the Tuition Fee Grant Subsidy by the Singapore Government.




|  |
| --- |
| **THIS BURSARY IS MADE POSSIBLE BY:** |
| Ms Anthonia Hui and Mr Leonardo Drago |
| Ms Anthonia went to work at the age of 6 to put herself and her sister to school as her parents were too poor to educate all the children, and chose to only put the sons to school. She learnt how to become financially independent and taking charge of her own destiny.   “Supporting a philanthropic bursary is not only an act of generosity, but also an investment in the future. By supporting those in need, we give them the opportunity to access education and training that will empower them to reach their full potential, creating positive ripple effect on the individual, their family and the community at large. With the bursary, we help to address social and economic inequality which is essential for a sustainable and just society. We are investing in the well-being of all members of society, both now and in the future.” – Ms Anthonia |

