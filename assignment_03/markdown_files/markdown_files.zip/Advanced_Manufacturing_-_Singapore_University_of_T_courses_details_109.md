Advanced_Manufacturing_-_Singapore_University_of_T



Advanced Manufacturing
======================

Overview
========

Advanced manufacturing courses focus on the use of technology and process improvement techniques to enhance the efficiency, quality, and flexibility of manufacturing operations and the technologies involved.

|  |  |
| --- | --- |
| **Course** | **Days** |
| **[Data Analytics for Semiconductor Industry Applications: Yield and Reliability Analysis](/course/data-analytics-for-semiconductor-industry-applications-yield-and-reliability-analysis/)** | **2** |
| **[Digital Design and Manufacturing](/course/digital-design-and-manufacturing/)** | **1** |
| **[Introduction to Energy Storage Device](/course/introduction-to-energy-storage-devices/)** | **1** |
| **[Robotics System Design & Development](/course/robotics-system-design-development/)** | **2** |
| [**Introduction to Algorithmic Engineering and Additive**](/course/introduction-to-algorithmic-engineering-and-additive-manufacturing/)**[Manufacturing](/course/Introduction-Algorithmic-Engineering)** | **2.5** |
| **[Introduction to Optics: Color Generation and Measurement](/course/introduction-to-optics-color-generation-and-measurement/)** | **2** |

###### What’s next

Find out more
-------------

##### Mailing list

Subscribe to our mailing list and learn about the latest developments in SUTD Academy.

Subscribe

##### Get in touch

Submit an enquiry or schedule a call with our friendly team at +65 6499 7171.

Contact us

