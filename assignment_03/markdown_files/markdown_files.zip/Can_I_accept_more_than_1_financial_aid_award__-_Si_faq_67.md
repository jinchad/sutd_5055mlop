Can_I_accept_more_than_1_financial_aid_award__-_Si



Can I accept more than 1 financial aid award?
=============================================

Yes, students may be awarded more than one financial aid award depending on your financial situation.

[Admissions](https://www.sutd.edu.sg/tag/admissions/)

---

