Am_I_eligible_for_the_SUTD_Community_Grant_(SCG)__



Am I eligible for the SUTD Community Grant (SCG)?
=================================================

Please refer to the [SUTD Community Grant page](/admissions/undergraduate/financing-options-and-aid/sutd-community-grant/) for the eligibility criteria.

[Admissions](https://www.sutd.edu.sg/tag/admissions/)

---

