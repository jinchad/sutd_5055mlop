Can_I_apply_for_incubation_even_if_I_am_not_from_S



Can I apply for incubation even if I am not from SUTD?
======================================================

Yes, we welcome you to join the SUTD startup ecosystem. Find out more about incubation spaces at SUTD [here](/enterprise/venture-innovation-entrepreneurship/support/incubation-space/).

[VIE](https://www.sutd.edu.sg/tag/vie/)

---

