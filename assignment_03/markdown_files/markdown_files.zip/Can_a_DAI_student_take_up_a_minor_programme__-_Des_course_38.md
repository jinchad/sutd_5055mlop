Can_a_DAI_student_take_up_a_minor_programme__-_Des



Can a DAI student take up a minor programme?
============================================

[Admissions](https://www.sutd.edu.sg/dai/tag/admissions/)

---

