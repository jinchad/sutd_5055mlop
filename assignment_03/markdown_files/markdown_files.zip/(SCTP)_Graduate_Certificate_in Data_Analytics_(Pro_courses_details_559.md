(SCTP)_Graduate_Certificate_in Data_Analytics_(Pro



(SCTP) Graduate Certificate in Data Analytics (Programming)
===========================================================

[Register interest](/admissions/academy/register-your-interest/?coursename=sctp-graduate-certificate-in-data-analytics(programming))

[Register interest](/admissions/academy/register-your-interest/?coursename=sctp-graduate-certificate-in-data-analytics(programming))

[Overview](/course/sctp-programmes-sctp-gradcert-in-data-analytics-programming/#tabs)

[Modules](/course/sctp-programmes-sctp-gradcert-in-data-analytics-programming/modules/#tabs)

[Course Fees and Funding](/course/sctp-programmes-sctp-gradcert-in-data-analytics-programming/course-fees-and-funding/#tabs)

[Policies and Financing Options](/course/sctp-programmes-sctp-gradcert-in-data-analytics-programming/policies-and-financing-options/#tabs)

Overview
========

Unlock the power of data with our comprehensive Graduate Certificate in Data Analytics (Programming). Designed for aspiring data professionals, this certificate programme focuses on the specifics of data manipulation and analysis, leveraging the Python programming language to make sense of complex datasets. Gain practical skills in data wrangling, preparation, validation, statistical analysis, and data science modelling, to equip you with the tools to extract valuable insights and make data-driven decisions. Whether you’re a beginner or an experienced professional, this programme will propel your career in the rapidly expanding field of data analytics.

Completing the (SCTP) Graduate Certificate in Data Analytics (Programming) is a pathway to attaining the (SCTP) ModularMaster in Data Science (Programming) certificate.

For more information about the ModularMaster Certificate and Graduate Certificate programmes, please refer to the **[FAQs on MM and GC](/admissions/academy/modular-master/faq/)**.

##### **Course Details**

**Course Dates:**  
No available course dates

##### **Who Should Attend**

* Those working in an industry or role dealing with data, who would benefit from data wrangling, data validation or data science modelling with the use of programming methods
* Participants in roles which require hands-on preparation of data with programming
* Ideal for participants who are in or looking to acquire skills for roles such as entry-level Data Engineers/Data Analysts

The **SkillsFuture Career Transition Programme (SCTP)** supports mid-career individuals in acquiring industry-relevant skills to improve employability and pivot to new sectors or job roles. It is a train-and-place programme that is available on a part-time or full-time format, ranging from three to 12 months.

Similar to existing requirements for other training grants administered by SSG, **trainees must fulfill minimum attendance requirements and pass the assessments to qualify for course fee subsidies. Trainees who are unable to meet these requirements, or exit the programme without a valid reason, may be asked to return the course fee subsidy that they have received, including any additional course fee funding support.** Under the SCTP scheme, trainees are encouraged to complete all modules to fully benefit from the intent of the programme.

For more information, please refer to the **[FAQs on SCTP](/repo/wp-content/uploads/sites/2/2024/11/FAQs-for-SCTP-Public-V01-1.pdf)**or the**[SkillsFuture website](https://www.skillsfuture.gov.sg/sctp)**.

Tags

[SkillsFuture Career Transition Programme (SCTP)](/admissions/academy/courses-and-modules/?academy-type-course=794)

###### What’s next

Find out more
-------------

##### Mailing list

Subscribe to our mailing list and learn about the latest developments in SUTD Academy.

Subscribe

##### Get in touch

Submit an enquiry or schedule a call with our friendly team at +65 6499 7171.

Contact us

