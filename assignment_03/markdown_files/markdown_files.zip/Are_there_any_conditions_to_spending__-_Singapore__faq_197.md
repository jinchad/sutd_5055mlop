Are_there_any_conditions_to_spending__-_Singapore_



Are there any conditions to spending?
=====================================

Yes, grants are subject to funding guidelines set by respective grant agencies and benefactors to ensure that they are properly utilised. Please contact us at entrepreneurship@sutd.edu.sg to find out about what is fundable and what is not.

[VIE](https://www.sutd.edu.sg/tag/vie/) [VIE Funding](https://www.sutd.edu.sg/tag/vie-funding/)

---

