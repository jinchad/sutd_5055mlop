Can_we_work_on_Satellites_or_Space_Industry_in_SUT



Can we work on Satellites or Space Industry in SUTD?
====================================================

SUTD itself does not have a satellites or space industry degrees. The satellites or space industry itself is really huge and would generally need graduates from a multitude of domains and disciplines. To answer this question on the possibility of pursuing a career in this industry, additional information on which segment of this industry that excites the individual is needed. Our advice is that students should consult and speak with your faculty mentors on the classes one should take to pursue their interest in the given area.

[EPD](https://www.sutd.edu.sg/epd/tag/epd/)

---

