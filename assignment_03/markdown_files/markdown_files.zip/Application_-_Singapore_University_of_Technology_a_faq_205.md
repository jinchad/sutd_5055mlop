Application_-_Singapore_University_of_Technology_a



Application
===========

We accept applications year-round. Share your ideas with us at entrepreneurship@sutd.edu.sg so we can better understand and support your project!



Next Evaluation in: TBA



Application Process:



1. Complete the attached Proposal Template and accompanying presentation deck.
2. Send the completed Proposal Template, Technology Disclosure (if applicable) and presentation deck to entrepreneurship@sutd.edu.sg
3. An email confirmation will be sent to notify that your proposal has been received. If you did not receive any confirmation email, please check in directly with entrepreneurship@sutd.edu.sg
4. We will inform the shortlisted eligible teams to present to an evaluation panel.
5. Successful applicants will be directly contacted via email.

[VIE](https://www.sutd.edu.sg/tag/vie/) [VIE Funding](https://www.sutd.edu.sg/tag/vie-funding/)

---

