Can_students_opt_for_coursework_instead_of_Thesis_



Can students opt for coursework instead of Thesis?
==================================================

No, as part of the graduation requirements, all students enrolled into the programme have to pass Thesis.

[MArch](https://www.sutd.edu.sg/asd/tag/march/)

---

