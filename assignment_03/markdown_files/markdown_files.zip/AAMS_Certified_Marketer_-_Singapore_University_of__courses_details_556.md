AAMS_Certified_Marketer_-_Singapore_University_of_



AAMS Certified Marketer
=======================

[Register interest](/admissions/academy/short-courses/short-courses-register-your-interest/?coursename=aams-certified-marketer)

[Register interest](/admissions/academy/short-courses/short-courses-register-your-interest/?coursename=aams-certified-marketer)

[Overview](/course/aams-certified-marketer/#tabs)

[Programme outline](/course/aams-certified-marketer/programme-outline/#tabs)

[Course fees and funding](/course/aams-certified-marketer/course-fees-and-funding/#tabs)

[Instructor](/course/aams-certified-marketer/instructor/#tabs)

[Policies and financing options](/course/aams-certified-marketer/policies-and-financing-options/#tabs)

### Overview

Learners will learn marketing fundamentals such as marketing strategies, foundation in sustainable marketing and the Singapore Code of Advertising Practice. Click [here](/repo/wp-content/uploads/sites/2/2024/11/Brochure-AAMS-Certified-Marketer-1.pdf) to view the course brochure.

##### **Course Details**

**Course Date:**  
Currently unavailable.

**Duration:**  
1 day, 9:00 am – 5:00 pm

##### **Who Should Attend**

Junior agency and brand marketers or mid-career.

Tags

[Short Courses](/admissions/academy/courses-and-modules/?academy-type-course=780)
[Digital Media](/admissions/academy/courses-and-modules/?discipline=1711)

###### What’s next

Find out more
-------------

##### Mailing list

Subscribe to our mailing list and learn about the latest developments in SUTD Academy.

Subscribe

##### Get in touch

Submit an enquiry or schedule a call with our friendly team at +65 6499 7171.

Contact us

