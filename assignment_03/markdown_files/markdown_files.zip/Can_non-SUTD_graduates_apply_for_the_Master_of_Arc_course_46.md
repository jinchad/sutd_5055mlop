Can_non-SUTD_graduates_apply_for_the_Master_of_Arc



Can non-SUTD graduates apply for the Master of Architecture programme?
======================================================================

Yes, we welcome applications from the public.

[MArch](https://www.sutd.edu.sg/asd/tag/march/)

---

