Can_I_apply_if_I_am_not_a_Singaporean_citizen__-_S



Can I apply if I am not a Singaporean citizen?
==============================================

Yes, non-Singapore citizens and International are welcome to apply for MSSD.

[MSSD](https://www.sutd.edu.sg/tag/mssd/)

---

