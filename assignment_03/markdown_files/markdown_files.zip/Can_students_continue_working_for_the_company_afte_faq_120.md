Can_students_continue_working_for_the_company_afte



Can students continue working for the company after the official internship period?
===================================================================================

SUTD students may continue working for the company after the official internship period, either as interns or company hires. This would be a direct arrangement between the company and the students. However, students will need to prioritise and ensure that the employment period does not coincide with any of their classes during school term.

[Career development](https://www.sutd.edu.sg/tag/career-development/)

---

