2025_-_Singapore_University_of_Technology_and_Desi



…

 [Term dates](/education/undergraduate/academic-calendar/term-dates) 

2025

[Term dates](https://www.sutd.edu.sg/education/undergraduate/academic-calendar/term-dates)

Academic calendar
=================

The Academic Calendar gives you an overview of dates for our 8 – 10 terms of each academic year. We have one undergraduate cohort intake in September of each year (before Academic Year 2020, our undergraduate intake was in May of each year).

[Overview](/education/undergraduate/academic-calendar/overview/#tabs)

[Term dates](/education/undergraduate/academic-calendar/term-dates/#tabs)

[AY2024 onwards](https://www.sutd.edu.sg/education/undergraduate/academic-calendar/overview/ay2024-onwards/#tabs)

[AY2020 to AY2023](https://www.sutd.edu.sg/education/undergraduate/academic-calendar/overview/ay2020-to-ay2023/#tabs)

[Before AY2020](https://www.sutd.edu.sg/education/undergraduate/academic-calendar/overview/before-ay2020/#tabs)

Please select

* 2025
* 2026
* 2027
* 2028

Term dates
==========

\*Information correct as of 22 January 2025 and is subject to change.



|  |  |
| --- | --- |
| **Trimester 1** | |
| **Terms 2, 4, 6, 8 & 10** | |
| Matriculation for Graduate Students | 22 January |
| IAP | 06 – 24 January |
| Bootcamp for Term 1 Freshmores | 06 – 17 January |
| UPOP | 20 – 25 January |
| Week 1 – 6 | 27 January – 08 March |
| Week 7 (Recess) | 09 – 16 March |
| Week 8 – 14 | 17 March – 03 May |
| Examinations | 30 April – 03 May |
| Commencement | 31 May & 01 June |
| Vacation for Freshmores, Sophmores & Graduate Students | 04 – 18 May |
| Vacation/Summer Programmes for Juniors | 04 May – 14 September |
| Internship/Exchange for Juniors | 19 May – 05 September |

|  |  |
| --- | --- |
| **Trimester 2** | |
| **Term 3 & 5** | |
| Bootcamp for Term 2 & Term 3 Freshmores | 25 August – 26 September 2025 |
| Week 1 – 6 | 19 May – 28 June |
| Week 7 (Recess) | 29 June – 06 July |
| Week 8 – 14 | 07 July – 23 August |
| Examinations | 20 – 22  August |
| Vacation for Freshmores & Juniors | 24 August 2025 – 01 January 2026 |
| Internship/Exchange for Juniors | 24 August 2025 – 01 January 2026 |
| UPOP | 08 – 12 September |

|  |  |
| --- | --- |
| **Trimester 3** | |
| **Terms 1, 7 & 9** | |
| Matriculation for Graduate Students | 10 September |
| Matriculation for Freshmores | 10 September |
| Orientation for Freshmores | 11 – 13 September |
| Week 1 – 6 | 15 September – 25 October |
| Week 7 (Recess) | 26 October – 02 November |
| Week 8 – 14 | 03 November – 20 December |
| Examinations | 17 – 19 December |
| Vacation for Freshmores & Seniors | 21 December 2025 – 01 January 2026 |

