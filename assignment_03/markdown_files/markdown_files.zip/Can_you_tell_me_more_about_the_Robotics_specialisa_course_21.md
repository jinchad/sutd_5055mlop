Can_you_tell_me_more_about_the_Robotics_specialisa



Can you tell me more about the Robotics specialisation track?
=============================================================

In the [Robotics specialisation track](/epd/education/undergraduate/specialisation-tracks/robotics/), students will gain knowledge of robotics fundamentals, skills in the modelling, design and development of robotic platforms, insights into their theoretical essentials and the expertise to apply these methods to real world problems.

[EPD](https://www.sutd.edu.sg/epd/tag/epd/)

---

