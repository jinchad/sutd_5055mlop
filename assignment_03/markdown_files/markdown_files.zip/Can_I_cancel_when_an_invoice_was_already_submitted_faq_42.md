Can_I_cancel_when_an_invoice_was_already_submitted



Can I cancel when an invoice was already submitted?
===================================================

Yes, but only if the invoice is not yet in “Paid” status. To cancel, please open the invoice that you have created. On top of the invoice page, there is a “Cancel” button.

Please refer to the [user guide on “How to Cancel an Invoice”](/wp-content/uploads/2024/12/How-to-Cancel-an-Invoice.pdf).

[Procurement](https://www.sutd.edu.sg/tag/procurement/)

---

