Can_I_create_an_invoice_for_services_rendered_good



Can I create an invoice for services rendered/goods delivered which don’t have a Purchase Order (PO) issued?
============================================================================================================

Yes. You can issue a non-PO invoice.

[Procurement](https://www.sutd.edu.sg/tag/procurement/)

---

