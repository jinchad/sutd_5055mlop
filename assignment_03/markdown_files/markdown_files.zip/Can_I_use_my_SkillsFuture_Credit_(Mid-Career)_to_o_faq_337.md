Can_I_use_my_SkillsFuture_Credit_(Mid-Career)_to_o



Can I use my SkillsFuture Credit (Mid-Career) to offset the course fees?
========================================================================

Effective 1 May 2024, a S$4,000 SkillsFuture Credit (Mid-Career) top-up will be available to reduce out-of-pocket expenses for specific courses aimed at improving employability. Currently, at SUTD Academy, this top-up is applicable solely to programmes within the SkillsFuture Career Transition Programme (SCTP).

[Academy](https://www.sutd.edu.sg/tag/academy/) [Academy Top 3](https://www.sutd.edu.sg/tag/academy-top-3/)

---

