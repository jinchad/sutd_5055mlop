Application_-_Singapore_University_of_Technology_a



Application
===========

Teams will have to complete the Create4Good Innovation Fund program held in September of every year. Upon completion, the team will be notified of their outcome for the grant after the program.

[VIE](https://www.sutd.edu.sg/tag/vie/) [VIE Funding](https://www.sutd.edu.sg/tag/vie-funding/)

---

