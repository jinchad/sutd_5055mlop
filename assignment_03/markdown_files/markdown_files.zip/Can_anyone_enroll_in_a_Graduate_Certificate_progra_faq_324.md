Can_anyone_enroll_in_a_Graduate_Certificate_progra



Can anyone enroll in a Graduate Certificate programme?
======================================================

The modules are open to members of the public, and since they are typically technical in nature, some basic scientific/technical knowledge, or relevant working experience, will be expected of the participants.

[Academy](https://www.sutd.edu.sg/tag/academy/)

---

