Are_testimonials_compulsory__-_Singapore_Universit



Are testimonials compulsory?
============================

Applicants will have to either upload one testimonial/recommendation letter or input the referee’s details and email address in the online application form. Your referee(s) should ideally be someone who knows you well (at least 6 months in recent years) and can attest to your character and academic ability, e.g. your principal or high school teacher (preferably teaching Maths/Science), or someone who knows you professionally, e.g. an internship or work supervisor.

[Admissions](https://www.sutd.edu.sg/tag/admissions/)

---

