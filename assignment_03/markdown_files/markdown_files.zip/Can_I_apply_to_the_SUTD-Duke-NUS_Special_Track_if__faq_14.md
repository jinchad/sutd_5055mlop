Can_I_apply_to_the_SUTD-Duke-NUS_Special_Track_if_



Can I apply to the SUTD-Duke-NUS Special Track if I have a reserved place at SUTD?
==================================================================================

Yes, students with a reserved place at SUTD from previous admissions exercises can apply to the SUTD-Duke-NUS Special Track. However, you can only choose one special programme:

* SUTD-Duke-NUS Special Track;
* SUTD Honours And Research Programme (SHARP);
* SUTD Technology Entrepreneurship Programme (STEP); or
* SUTD-Tianjin Eco-City (SUTD-TEC) Programme

Students who are in other special programmes (apart from the SUTD-Duke-NUS Special Track) and are interested in pursuing a Doctor of Medicine (MD) degree at Duke-NUS Medical School can still apply to Duke-NUS after graduating from SUTD.

[SUTD-Duke-NUS](https://www.sutd.edu.sg/tag/sutd-duke-nus/)

---

