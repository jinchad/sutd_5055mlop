Can_anyone_enroll_in_a_ModularMaster_Certificate_P



Can anyone enroll in a ModularMaster Certificate Programme?
===========================================================

Modules are open to the public. Due to their technical nature, participants are expected to have basic scientific or technical knowledge, or relevant work experience.

[Academy](https://www.sutd.edu.sg/tag/academy/)

---

