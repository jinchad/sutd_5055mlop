Ask_admissions_-_Singapore_University_of_Technolog



[Undergraduate admissions](/admissions/undergraduate) 

Ask admissions

[Undergraduate admissions](https://www.sutd.edu.sg/admissions/undergraduate)

Ask admissions
==============

### Ask Admissions

"\*" indicates required fields

You may refer to our [Frequently Asked Questions (FAQs)](/admissions/undergraduate/faq/) for general admissions information. For all other enquiries, please fill out our form.

I am a\*

Please selectProspective student / ParentApplicantIncoming StudentEducators / School

My enquiry is related to\*

Please selectConsultationAdmissions RequirementsScholarships & Financial AidCurriculum & ProgrammeSpecial Programmes – SHARP/STEP/SUTD-DUKE-NUSHostel StayGroup Campus VisitOthers

My enquiry is related to\*

Please selectConsultationChange of particulars or intake yearSupporting documentationInterview SchedulingScholarships & Financial Aid Application outcome and offer acceptanceTechnical IssuesOthers

My enquiry is related to\*

Please selectIntegrated Learning ProgrammeEarly MatriculationNS Disruption / DefermentStudent Pass (for international students)Others

My enquiry is related to\*

Please selectLearning journeyTalksOthers

My query\*

Please describe your query in detail so we may assist expeditiously.

##### PERSONAL DETAILS

First name\*

Last Name\*

Email\*

Mobile number\*

##### APPLICATION INFORMATION

Application Number (if applicable)

My expected year of university admissions

2024202520262027Not Applicable

Qualification I am applying with

Please selectSingapore-Cambridge GCE A-LevelsLocal DiplomaInternational Baccalaureate DiplomaNUS High School DiplomaOther International QualificationsOther

If other, please specify

#####

Consent\*

By checking the box and clicking ‘Submit’, I hereby consent to the collection and use of my personal information as captured on the form by Singapore University of Technology and Design (SUTD), including the disclosure to SUTD trusted third parties. The personal information collected will be used for the purposes of communicating relevant news about SUTD and invitations to future events. I may choose, at any point, to unsubscribe from any of the above correspondences by an email to dpo@sutd.edu.sg.\*

Submit

Δ

