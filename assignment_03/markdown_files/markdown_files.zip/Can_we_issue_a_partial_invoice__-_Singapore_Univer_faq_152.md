Can_we_issue_a_partial_invoice__-_Singapore_Univer



Can we issue a partial invoice?
===============================

For PO issued by quantity, it is possible to amend the quantity to a lower amount for partial billing. For services PO, partial invoice is not possible as they cover over a period.

[Procurement](https://www.sutd.edu.sg/tag/procurement/)

---

