Capstone_design_showcase_-_Singapore_University_of



…

 [Capstone](/education/undergraduate/capstone) 

Capstone design showcase

[Capstone](https://www.sutd.edu.sg/education/undergraduate/capstone)

Capstone programme
==================

[Overview](/education/undergraduate/capstone/overview/#tabs)

[For students](/education/undergraduate/capstone/for-students/#tabs)

[For industry partners](/education/undergraduate/capstone/for-industry-partners/#tabs)

[Capstone design showcase](/education/undergraduate/capstone/capstone-design-showcase/#tabs)

### Capstone Design Showcase



The Capstone Design Showcase is held annually as a culminating event for the Capstone Design project. Our final year students pursuing different degree programmes come together to work in multi-disciplinary teams to solve real-world challenges faced by our industry partners.  
   
The Showcase is generally held on campus where visitors and industry partners get to interact with our students as they present their projects. Over the past few years, affected by the pandemic, the Showcase has also gone virtual for the first time in 2020 and even taking on a hybrid format (both on-campus and online) in 2022. Check out the virtual showcases from the past years:



* [**Capstone Design Virtual Showcase 2023/2024**](https://capstoneshowcase.sutd.edu.sg/)
* [**Capstone Design Virtual Showcase 2022**](https://capstone2022.sutd.edu.sg/)
* [**Capstone Design Virtual Showcase 2021**](https://capstone2021.sutd.edu.sg/)
* [**Capstone Design Virtual Showcase 2020**](https://capstone2020.sutd.edu.sg/)

###### WHAT'S NEW

Find out more
-------------

##### Get in touch

For enquiries and more information about the Capstone Programme, please contact the Capstone Programme Office. Telephone: 6499 4076 / Email: capstone@sutd.edu.sg

[Contact us](mailto:%20capstone@sutd.edu.sg)

