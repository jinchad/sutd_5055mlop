Can_you_explain_more_about_the_self-directed_progr



Can you explain more about the self-directed programme specialisation?
======================================================================

The [self-directed track](/epd/education/undergraduate/specialisation-tracks/self-directed-programme/) offers students the option to design a personalized study plan that will arm you with the necessary knowledge (e.g. Sustainability, Materials Science) and skills to pursue unique or non-traditional careers centered around your personal interests.

[EPD](https://www.sutd.edu.sg/epd/tag/epd/)

---

