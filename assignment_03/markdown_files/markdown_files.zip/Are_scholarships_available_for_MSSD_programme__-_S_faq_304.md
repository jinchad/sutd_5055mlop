Are_scholarships_available_for_MSSD_programme__-_S



Are scholarships available for MSSD programme?
==============================================

National Cybersecurity Postgraduate Scholarship (NCPS) and SkillsFuture Study Awards are available for Singapore Citizens and Permanent Residents. More information can be found at the following links.



* <https://www.imda.gov.sg/programme-listing/Singapore-Digital-Scholarship>
* <https://www.skillsfuture.gov.sg/initiatives/mid-career>

[MSSD](https://www.sutd.edu.sg/tag/mssd/)

---

