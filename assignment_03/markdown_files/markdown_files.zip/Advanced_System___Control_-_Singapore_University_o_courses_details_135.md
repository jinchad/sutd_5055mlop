Advanced_System___Control_-_Singapore_University_o



Advanced System & Control
=========================

Extending systems modeling and feedback control theory and applications to include periodic signals and discrete-time systems. Mathematical modeling and analysis of discrete time systems in various disciplines using state-space, pulse transfer function and z-transform. Relating controllability and observability and their canonical forms to synthesize and design both continuous and discrete-time controllers. Introduction of pole-placement based controller design and formulation of state observers. Main Image Credit

Tags

[EPD](/education/undergraduate/courses/?pillar-cluster=44)
[ISTD](/education/undergraduate/courses/?pillar-cluster=11)
[ASD](/education/undergraduate/courses/?pillar-cluster=1167)

