Can_males_serving_Singapore_National_Service_apply



Can males serving Singapore National Service apply? Will places be reserved for NSmen for post-NS admission?
============================================================================================================

Yes, males currently serving National Service, are welcome to apply. We will reserve a place for male students who accepted our offers, for the immediate intake year after your ORD.

[SHARP](https://www.sutd.edu.sg/tag/sharp/)

---

