Can_I_know_why_my_application_is_rejected__-_Singa



Can I know why my application is rejected?
==========================================

We regret to inform applicants that the University does not provide specific reasons for unsuccessful applications, except that selection is based on a competitive basis for limited places for the programmes.

[MArch](https://www.sutd.edu.sg/tag/march/)

---

