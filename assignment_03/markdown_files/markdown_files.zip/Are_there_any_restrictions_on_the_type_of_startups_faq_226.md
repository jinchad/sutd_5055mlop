Are_there_any_restrictions_on_the_type_of_startups



Are there any restrictions on the type of startups?
===================================================

Startups should not have a proposed business idea that falls under the list provided below:




Cafes, restaurants, night clubs, lounges, bars, foot reflexology, massage parlours, gambling, prostitution, social escort services, employment agencies (including recruiting foreign work permit holders and workers/support staff, relocation services, and manpower services), and geomancy.

[VIE](https://www.sutd.edu.sg/tag/vie/) [VIE Funding](https://www.sutd.edu.sg/tag/vie-funding/)

---

