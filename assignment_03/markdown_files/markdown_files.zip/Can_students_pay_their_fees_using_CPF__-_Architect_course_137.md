Can_students_pay_their_fees_using_CPF__-_Architect



Can students pay their fees using CPF?
======================================

No, the University does not have provisions for postgraduate students to pay their fees using their own CPF/their parents’ CPF.

[MArch](https://www.sutd.edu.sg/asd/tag/march/)

---

