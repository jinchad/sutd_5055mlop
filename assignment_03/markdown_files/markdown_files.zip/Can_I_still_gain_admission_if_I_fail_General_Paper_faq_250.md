Can_I_still_gain_admission_if_I_fail_General_Paper



Can I still gain admission if I fail General Paper?
===================================================

You may still apply even if you did not pass your General Paper. We will take into consideration your grades for other GCE A-Level subjects as well as non-academic credentials in assessing your application holistically.

[Admissions](https://www.sutd.edu.sg/tag/admissions/)

---

