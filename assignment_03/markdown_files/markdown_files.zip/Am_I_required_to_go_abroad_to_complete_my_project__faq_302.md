Am_I_required_to_go_abroad_to_complete_my_project_



Am I required to go abroad to complete my project/ thesis?
==========================================================

No. A project/thesis can also be complete at SUTD or at a partner organization in Singapore. In the latter case, the partner organization will be a commercial firm or a Singapore Government agency where a student completes a project in the area of cyber security. In this case a faculty advisor at SUTD and a co-advisor at the partner organization will serve as project advisors.

[MSSD](https://www.sutd.edu.sg/tag/mssd/)

---

