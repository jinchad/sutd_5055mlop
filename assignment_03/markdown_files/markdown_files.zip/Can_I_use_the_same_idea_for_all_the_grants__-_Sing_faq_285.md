Can_I_use_the_same_idea_for_all_the_grants__-_Sing



Can I use the same idea for all the grants?
===========================================

Definitely! However, each successful pitch will have a different set of milestones attached to each award to help push your project development forward.

[VIE](https://www.sutd.edu.sg/tag/vie/) [VIE Programmes](https://www.sutd.edu.sg/tag/vie-programmes/)

---

