Are_there_any_subject_pre-requisites_for_DAI__Are_



Are there any subject pre-requisites for DAI? Are students with advanced mathematics proficiency, programming or design knowledge expected to do better in this course?
=======================================================================================================================================================================

---

