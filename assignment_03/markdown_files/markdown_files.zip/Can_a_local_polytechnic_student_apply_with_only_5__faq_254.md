Can_a_local_polytechnic_student_apply_with_only_5_



Can a local polytechnic student apply with only 5 semesters results? Will those applying with a full set of Poly results have an advantage?
===========================================================================================================================================

If you are currently in your final semester, you can apply by submitting results from your first five semesters during the [application window](/admissions/undergraduate/local-diploma/application-timeline/), and upload your final transcript **within three days upon receipt**. There will not be any advantage accorded to either groups applying with five semesters or full diploma results.

[Admissions](https://www.sutd.edu.sg/tag/admissions/)

---

