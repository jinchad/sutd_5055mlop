Awards_-_Singapore_University_of_Technology_and_De



…

 [Scholarship](/admissions/undergraduate/scholarship) 

Awards

[Scholarship](https://www.sutd.edu.sg/admissions/undergraduate/scholarship)

Scholarships and awards
=======================

[Scholarships administered by SUTD](/admissions/undergraduate/scholarship/sutd-administered/#tabs)

[Externally sponsored scholarships](/admissions/undergraduate/scholarship/external-sponsored/#tabs)

[Awards](/admissions/undergraduate/scholarship/awards/#tabs)

### Awards

Apart from the SUTD scholarships, awards are given out to recognise students with outstanding achievements and attributes.

These awards will be evaluated along with your application for admission. Should you be successful in your application and eligible for an award, we will inform you of the specific award along with the admission offer.

##### Awards currently available

1. [SUTD Design Innovator (DI) Award](/admissions/undergraduate/scholarship/awards/sutd-design-innovator-award/) (new in AY2025)

