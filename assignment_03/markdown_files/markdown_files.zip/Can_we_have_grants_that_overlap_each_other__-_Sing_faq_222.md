Can_we_have_grants_that_overlap_each_other__-_Sing



Can we have grants that overlap each other?
===========================================

No, you should only hold onto 1 grant at any one time.

[VIE](https://www.sutd.edu.sg/tag/vie/) [VIE Programmes](https://www.sutd.edu.sg/tag/vie-programmes/)

---

