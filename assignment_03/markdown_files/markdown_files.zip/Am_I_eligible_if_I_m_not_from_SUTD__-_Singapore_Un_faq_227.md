Am_I_eligible_if_I_m_not_from_SUTD__-_Singapore_Un



Am I eligible if I’m not from SUTD?
===================================

We are interested to find out more about you and your start-up. Come and speak to us at entrepreneurship@sutd.edu.sg.

[VIE](https://www.sutd.edu.sg/tag/vie/) [VIE Programmes](https://www.sutd.edu.sg/tag/vie-programmes/)

---

