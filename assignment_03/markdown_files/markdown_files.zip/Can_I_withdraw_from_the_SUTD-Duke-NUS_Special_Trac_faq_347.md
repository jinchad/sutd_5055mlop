Can_I_withdraw_from_the_SUTD-Duke-NUS_Special_Trac



Can I withdraw from the SUTD-Duke-NUS Special Track during the course of my undergraduate studies?
==================================================================================================

Although you are not required to make a binding commitment to Duke-NUS at the time of admission, you should inform SUTD and Duke-NUS of your withdrawal from the track at least the year preceding medical school matriculation. You can still continue with SUTD’s normal undergraduate degree programme should you discontinue with the track, subject to meeting the academic requirements for the undergraduate programme.

[SUTD-Duke-NUS](https://www.sutd.edu.sg/tag/sutd-duke-nus/)

---

