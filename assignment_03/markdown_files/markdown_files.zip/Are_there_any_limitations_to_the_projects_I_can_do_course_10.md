Are_there_any_limitations_to_the_projects_I_can_do



Are there any limitations to the projects I can do in my UG research?
=====================================================================

The first thing to do if you are interested in research is to get to know the various research areas pursued by EPD professors, and find out what topic interests you. Discuss with the professor to find out what is required to participate in research in that topic. Every UG student is assigned a faculty mentor, which is also a great source of information on research topics.

[EPD](https://www.sutd.edu.sg/epd/tag/epd/)

---

