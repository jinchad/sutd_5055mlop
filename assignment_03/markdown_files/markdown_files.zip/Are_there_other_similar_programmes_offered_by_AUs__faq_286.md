Are_there_other_similar_programmes_offered_by_AUs_



Are there other similar programmes offered by AUs?
==================================================

There are several undergraduate and graduate level programs available in Singapore that focus on cyber security. However, SUTD is the first university in Singapore to offer a Master of Science in Security by Design. Distinctive features of this programme include (a) focus on the design of security solutions, (b) a student-centric pedagogy that uses active learning, flipped classroom, and multidisciplinary projects, (c) access to one of a kind testbeds and test skids for experimentation, and (d) opportunity for international attachment to complete a project or a thesis.

[MSSD](https://www.sutd.edu.sg/tag/mssd/) [MSSD Top 3](https://www.sutd.edu.sg/tag/mssd-top-3/)

---

