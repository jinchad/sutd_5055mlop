Are_scholarships_available_for_the_SUTD_Honours_an



Are scholarships available for the SUTD Honours and Research Programme (SHARP)?
===============================================================================

All SHARP students will be considered for scholarships, awards will be based on merit and competition. Students enrolled in SHARP will be eligible for the [research stipends and grants listed here](/education/undergraduate/special-programmes/sharp/application-and-financing/scholarships/).

[SHARP](https://www.sutd.edu.sg/tag/sharp/)

---

